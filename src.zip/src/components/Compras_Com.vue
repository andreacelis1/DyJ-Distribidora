<template>
    <div class="hello">
        <h1>Soy Compras</h1>
      <v-img alt="ventas logo" src="../assets/compras.jpg"></v-img>
      

    </div>
 

  </template>
  
  <script>
  export default {
    name: 'Compras_Com',
    props: {

    }
  }
  </script>
  <style scoped>
  h3 {
    margin: 40px 0 0;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    display: inline-block;
    margin: 0 10px;
  }
  a {
    color: #42b983;
  }
  img{
    width: 20%;
  }
  </style>