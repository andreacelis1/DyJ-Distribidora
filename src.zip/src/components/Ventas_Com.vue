<template>
  <div class="hello">
    <h1>Soy Ventas</h1>
    <v-img alt="ventas logo" src="../assets/ventas.png"></v-img>


  </div>
</template>
    
<script>
export default {
  name: 'Ventas_Com',
  props: {

  },
  data() {
    return {

    }

  }
}


</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

img {
  width: 20%;
}
</style>